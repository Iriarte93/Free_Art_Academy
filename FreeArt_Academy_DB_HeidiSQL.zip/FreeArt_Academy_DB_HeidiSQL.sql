-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.4.28-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para tfm
CREATE DATABASE IF NOT EXISTS `tfm` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `tfm`;

-- Volcando estructura para tabla tfm.user
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userPassword` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT current_timestamp(),
  `userName` varchar(255) NOT NULL,
  `userEmail` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_85432bb369f1a54116c4e4d2ee` (`userEmail`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla tfm.user: ~14 rows (aproximadamente)
INSERT INTO `user` (`id`, `userPassword`, `createdAt`, `userName`, `userEmail`) VALUES
	(1, 'test123', '2024-09-28 12:42:39', 'test', '123456@gmail.com'),
	(2, 'test123', '2024-09-28 12:44:39', 'test', '214456@gmail.com'),
	(3, '$2b$10$INTQbdffpfoGKTSzO66CUOc7EEjYZdBFAYwBlRgU0uQ0ZLUUDB.Pi', '2024-09-28 12:57:07', 'test', 'nuevocorreo@gmail.com'),
	(4, '$2b$10$vAIjyJi5hyivDfQKgLAmCuiUdqSx/xS5p5uc0TbFu8blA3VXPCky6', '2024-09-28 23:34:47', 't123est', 'n123123uevocorreo@gmail.com'),
	(5, '$2b$10$1NG2MPJv5rMPHpl8b.zfdO5rq69YRlIeHjvryiRff9tK4Hw8hBFPa', '2024-09-28 23:45:29', 't1323est', 'n123123uevoo@gmail.com'),
	(6, '$2b$10$e7RAbi91l/OvT8r/Uwa.Lerxs06N8ylhobW.SLs6D0Q1Msh6OlsrC', '2024-09-28 23:46:25', 'Aitor', '1312313@gmail.com'),
	(7, '$2b$10$FAe/aoRmSdV2VdRS04Ql2ur6H/QQPKZ/RJyqQNqILwgyriDU7foTa', '2024-09-28 23:49:49', 'Aitor', 'federico313@gmail.com'),
	(8, '$2b$10$3AYcpAgyjSKbIFZ0O5vrsed1q9gLjGPDXGUuepxJuZg5ue.d84ImS', '2024-09-28 23:55:38', 'Tre', 'tre@gmail.com'),
	(9, '$2b$10$SsNoiX9deZUdWDd1oQQ3I.IaH71D7p98Gpsmj5LiRjXK1KvcEDX1.', '2024-09-29 00:00:55', 'OtroUsuario', 'alarico@gmail.com'),
	(10, '$2b$10$6AT6D7zvk1ZTfjxvXZ.JWeLrTtm2Jo6xh90RW.G8G3EQlCY7cN0JC', '2024-09-29 00:01:16', 'OtroUsua23rio', ''),
	(12, '$2b$10$LJhz26FBA0rDNRdQNljBQuxiwoYgNdTlmRpvg7Kh36yGbTBRLA/tm', '2024-09-29 23:13:56', 'Administrador', 'admin@gmail.com'),
	(13, '$2b$10$.QqYAXMAJsnAgg705uQ5t.4HylrJSgquAoYt9alICWhjCAp8b1Ltu', '2024-09-30 13:16:18', 'Carlos', 'carlos@gmail.com'),
	(14, '$2b$10$NjP0h41YJ8W2UwI0Qn.G0utKZtUSGMgxwpQ9hu6KSmWnO47GUMcLq', '2024-09-30 13:35:12', 'Prueba', 'prueba@gmail.com'),
	(15, '$2b$10$0f4dbLJBl2j5j/NqAMheOO7fLYj59txtYXOO58G8wOM3SjNebhC1a', '2024-09-30 14:13:39', 'Trini', 'trini@gmail.com');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
